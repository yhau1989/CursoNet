﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace websiteSamuel
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var name = "Samuel Pilay Muñoz";
            int anio = 1989;
            Label1.Text = $"Fecha: {System.DateTime.Now} Nombre: {name} nací en el año {34546/4}";
        }
    }
}
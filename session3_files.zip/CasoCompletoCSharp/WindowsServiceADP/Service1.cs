﻿using Logical;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace WindowsServiceADP
{
    public partial class Service1 : ServiceBase
    {
        Timer tmrMailer;
        bool _ProcesandoMailer;

        public Service1()
        {
            InitializeComponent();
            Double interval = Double.Parse(ConfigurationSettings.AppSettings["intervalo_de_ejecucion"].ToString());
            tmrMailer = new Timer(interval);
            tmrMailer.Elapsed += new System.Timers.ElapsedEventHandler(tmrMailer_Elapsed);
        }

        protected override void OnStart(string[] args)
        {
            // TODO: Add code here to start your service.
            tmrMailer.Enabled = true;
            _ProcesandoMailer = false;
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
            tmrMailer.Enabled = false;
            _ProcesandoMailer = true;
        }


        void tmrMailer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            this.process();

        }

        private void process()
        {
            if (!_ProcesandoMailer)
            {
                _ProcesandoMailer = true;

                try
                {
                    ClaseTest hcont = new ClaseTest("Samuel", "Pilay Muñoz", 30, "Esto es una clase");
                    hcont.escribirArchivo();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    _ProcesandoMailer = false;
                }

            }
        }
    }
}

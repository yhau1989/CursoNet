﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical
{
    public class Logueo
    {
        public string sourceFile { get; set; } = null;
        public string nameFile { get; set; } = null;

        public string WriteArchivo(string mensaje)
        {
            string file = null;
            try
            {
                System.IO.File.WriteAllText($"{this.sourceFile}{this.nameFile}.txt", mensaje);
                file = $"Se grabo el archivo {this.nameFile}.txt con exito";
            }
            catch (Exception ex)
            {
                file = $@"Error al generar el archivo: {System.Environment.NewLine} 
                          Detalle de error: {ex.Message} {System.Environment.NewLine}
                          Error en {ex.Source}";
            }

            return file;
        }

        

    }
}

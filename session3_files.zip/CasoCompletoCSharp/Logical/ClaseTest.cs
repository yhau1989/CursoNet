﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical
{
    public class ClaseTest
    {
        public string nombres { get; set; }
        public string apellidos { get; set; }
        public int edad { get; set; }
        public string mensaje { get; set; }

        public ClaseTest(string _nombre, string _apellidos, int _edad, string _mensaje)
        {
            nombres = _nombre;
            apellidos = _apellidos;
            edad = _edad;
            mensaje = _mensaje;
            escribirArchivo();
        }

        public string escribirArchivo()
        {
            Logueo log = new Logueo() {
                nameFile = System.Configuration.ConfigurationManager.AppSettings[""].ToString(),
                sourceFile = getNameDocumentNow()
            };

            return log.WriteArchivo($@"
                Nombre: {nombres} {System.Environment.NewLine} 
                Apellidos: {apellidos} {System.Environment.NewLine} 
                Edad: {edad} {System.Environment.NewLine} 
                Mensaje: {mensaje} {System.Environment.NewLine} 
                Fecha: {DateTime.Now.ToString("ddMMyyyymmss")}
            ");
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        /// <![CDATA[ 
        /// Autor: Samuel Pilay Muñoz
        /// fecha creación: 2020-01-23 14:41:37
        /// ]]>	
        public string getNameDocumentNow() { return $"File_{DateTime.Now.ToString("ddMMyyyymmss")}"; }
    }
}
